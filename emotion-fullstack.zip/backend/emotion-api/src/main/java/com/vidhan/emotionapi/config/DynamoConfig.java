
package com.vidhan.emotionapi.config;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import software.amazon.awssdk.regions.Region;
import software.amazon.awssdk.services.dynamodb.DynamoDbClient;
import software.amazon.awssdk.enhanced.dynamodb.*;
import java.net.URI;

@Configuration
public class DynamoConfig {
  @Value("${aws.region}") String region;
  @Value("${aws.endpoint}") String endpoint;
  @Bean
  public DynamoDbEnhancedClient enhancedClient(){
    var b = DynamoDbClient.builder().region(Region.of(region));
    if(endpoint!=null && !endpoint.isBlank()) b.endpointOverride(URI.create(endpoint));
    return DynamoDbEnhancedClient.builder().dynamoDbClient(b.build()).build();
  }
}
