
package com.vidhan.emotionapi;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EmotionApiApplication {
  public static void main(String[] args) { SpringApplication.run(EmotionApiApplication.class, args); }
}
