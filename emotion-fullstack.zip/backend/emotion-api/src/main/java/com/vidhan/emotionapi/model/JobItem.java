
package com.vidhan.emotionapi.model;

import lombok.*;
import software.amazon.awssdk.enhanced.dynamodb.mapper.annotations.*;

@Data @Builder @NoArgsConstructor @AllArgsConstructor
@DynamoDbBean
public class JobItem {
  private String pk; private String sk; private String modality; private String s3Key; private String inputText;
  private String modelResponseJson; private Long createdAt;
  @DynamoDbPartitionKey public String getPk(){ return pk; }
  @DynamoDbSortKey public String getSk(){ return sk; }
}
