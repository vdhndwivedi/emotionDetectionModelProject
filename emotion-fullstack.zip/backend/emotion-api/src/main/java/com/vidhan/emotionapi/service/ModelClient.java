
package com.vidhan.emotionapi.service;

import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.io.ByteArrayResource;
import org.springframework.http.*;
import org.springframework.stereotype.Service;
import org.springframework.util.*;
import org.springframework.web.client.RestClient;
import java.util.*;

@Service @RequiredArgsConstructor
public class ModelClient {
  private final RestClient rest = RestClient.create();
  @Value("${app.ai.modelBaseUrl}") String base;
  @Value("${app.ai.textPath}") String textPath;
  @Value("${app.ai.audioPath}") String audioPath;
  @Value("${app.ai.videoPath}") String videoPath;

  public String inferText(String text){
    Map<String,String> body = Map.of("text", text);
    return rest.post().uri(base + textPath).contentType(MediaType.APPLICATION_JSON).body(body).retrieve().body(String.class);
  }
  public String inferAudio(byte[] bytes, String filename){
    MultiValueMap<String,Object> form = new LinkedMultiValueMap<>();
    form.add("file", new ByteArrayResource(bytes){ @Override public String getFilename(){ return filename; }});
    return rest.post().uri(base + audioPath).contentType(MediaType.MULTIPART_FORM_DATA).body(form).retrieve().body(String.class);
  }
  public String inferVideo(byte[] bytes, String filename){
    MultiValueMap<String,Object> form = new LinkedMultiValueMap<>();
    form.add("file", new ByteArrayResource(bytes){ @Override public String getFilename(){ return filename; }});
    return rest.post().uri(base + videoPath).contentType(MediaType.MULTIPART_FORM_DATA).body(form).retrieve().body(String.class);
  }
}
