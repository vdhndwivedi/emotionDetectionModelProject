
package com.vidhan.emotionapi.repo;

import com.vidhan.emotionapi.model.*;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import software.amazon.awssdk.enhanced.dynamodb.*;
import software.amazon.awssdk.enhanced.dynamodb.model.*;

@Service @RequiredArgsConstructor
public class DynamoRepo {
  private final DynamoDbEnhancedClient client;
  @Value("${app.dynamodb.table}") String tableName;
  private DynamoDbTable<UserItem> userTable(){ return client.table(tableName, TableSchema.fromBean(UserItem.class)); }
  private DynamoDbTable<JobItem> jobTable(){ return client.table(tableName, TableSchema.fromBean(JobItem.class)); }
  public void putUser(UserItem u){ userTable().putItem(u); }
  public UserItem getUser(String username){
    var key = Key.builder().partitionValue("USER#"+username).sortValue("PROFILE").build();
    return userTable().getItem(r->r.key(key));
  }
  public void putJob(JobItem j){ jobTable().putItem(j); }
  public JobItem getJob(String username, String jobId){
    var key = Key.builder().partitionValue("USER#"+username).sortValue("JOB#"+jobId).build();
    return jobTable().getItem(r->r.key(key));
  }
}
