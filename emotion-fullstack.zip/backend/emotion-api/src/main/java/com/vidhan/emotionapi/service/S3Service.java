
package com.vidhan.emotionapi.service;

import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import software.amazon.awssdk.regions.Region;
import software.amazon.awssdk.services.s3.*;
import software.amazon.awssdk.services.s3.model.*;
import software.amazon.awssdk.core.sync.RequestBody;
import java.net.URI;

@Service @RequiredArgsConstructor
public class S3Service {
  @Value("${app.s3.bucket}") String bucket;
  @Value("${aws.region}") String region;
  @Value("${aws.endpoint}") String endpoint;
  private S3Client s3(){ var b=S3Client.builder().region(Region.of(region)); if(endpoint!=null && !endpoint.isBlank()) b.endpointOverride(URI.create(endpoint)); return b.build(); }
  public String putObject(String key, byte[] data, String contentType){
    s3().putObject(PutObjectRequest.builder().bucket(bucket).key(key).contentType(contentType).build(), RequestBody.fromBytes(data));
    return key;
  }
}
