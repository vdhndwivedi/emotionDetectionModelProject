
package com.vidhan.emotionapi.controller;

import com.vidhan.emotionapi.model.UserItem; import com.vidhan.emotionapi.repo.DynamoRepo; import com.vidhan.emotionapi.security.JwtService;
import lombok.*; import org.springframework.http.*; import org.springframework.validation.annotation.Validated; import org.springframework.web.bind.annotation.*; import org.springframework.security.crypto.password.PasswordEncoder;
import jakarta.validation.constraints.*; import jakarta.validation.*; import java.util.*;

@RestController @RequestMapping("/api/auth") @RequiredArgsConstructor
public class AuthController {
  private final DynamoRepo repo; private final PasswordEncoder encoder; private final JwtService jwt;

  @PostMapping("/register")
  public ResponseEntity<?> register(@Validated @RequestBody RegisterReq req){
    if(repo.getUser(req.getUsername())!=null) return ResponseEntity.status(HttpStatus.CONFLICT).body(Map.of("error","Username exists"));
    var u = UserItem.builder().pk("USER#"+req.getUsername()).sk("PROFILE").username(req.getUsername()).email(req.getEmail()).passwordHash(encoder.encode(req.getPassword())).build();
    repo.putUser(u); return ResponseEntity.ok(Map.of("message","registered"));
  }
  @PostMapping("/login")
  public ResponseEntity<?> login(@Validated @RequestBody LoginReq req){
    var u = repo.getUser(req.getUsername());
    if(u==null) return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body(Map.of("error","Invalid credentials"));
    if(!encoder.matches(req.getPassword(), u.getPasswordHash())) return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body(Map.of("error","Invalid credentials"));
    String token = jwt.issueToken(req.getUsername());
    return ResponseEntity.ok(Map.of("token", token, "username", req.getUsername()));
  }
}
record RegisterReq(@NotBlank String username, @Email String email, @Size(min=6) String password){}
record LoginReq(@NotBlank String username, @NotBlank String password){}
