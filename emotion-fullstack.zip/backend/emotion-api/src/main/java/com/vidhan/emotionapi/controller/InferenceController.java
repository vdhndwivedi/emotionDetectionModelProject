
package com.vidhan.emotionapi.controller;

import com.vidhan.emotionapi.model.JobItem; import com.vidhan.emotionapi.repo.DynamoRepo; import com.vidhan.emotionapi.service.ModelClient; import com.vidhan.emotionapi.service.S3Service;
import lombok.RequiredArgsConstructor; import org.json.JSONObject; import org.springframework.http.*; import org.springframework.security.core.context.SecurityContextHolder; import org.springframework.web.bind.annotation.*; import org.springframework.web.multipart.MultipartFile; import java.util.*;

@RestController @RequestMapping("/api/infer") @RequiredArgsConstructor
public class InferenceController {
  private final S3Service s3; private final DynamoRepo repo; private final ModelClient model;
  private String currentUser(){ return (String) SecurityContextHolder.getContext().getAuthentication().getPrincipal(); }

  @PostMapping("/text")
  public ResponseEntity<?> text(@RequestBody Map<String,String> body){
    String username=currentUser(); String text=body.get("text"); String modelJson=model.inferText(text); String jobId=UUID.randomUUID().toString();
    repo.putJob(JobItem.builder().pk("USER#"+username).sk("JOB#"+jobId).modality("text").inputText(text).modelResponseJson(modelJson).createdAt(System.currentTimeMillis()).build());
    return ResponseEntity.ok(Map.of("jobId",jobId, "result", new JSONObject(modelJson).toMap()));
  }

  @PostMapping(path="/audio", consumes=MediaType.MULTIPART_FORM_DATA_VALUE)
  public ResponseEntity<?> audio(@RequestPart("file") MultipartFile file) throws Exception{
    String username=currentUser(); String jobId=UUID.randomUUID().toString(); String key="uploads/"+username+"/"+jobId+"/"+file.getOriginalFilename();
    s3.putObject(key, file.getBytes(), file.getContentType()); String modelJson=model.inferAudio(file.getBytes(), file.getOriginalFilename());
    repo.putJob(JobItem.builder().pk("USER#"+username).sk("JOB#"+jobId).modality("audio").s3Key(key).modelResponseJson(modelJson).createdAt(System.currentTimeMillis()).build());
    return ResponseEntity.ok(Map.of("jobId",jobId, "result", new JSONObject(modelJson).toMap()));
  }

  @PostMapping(path="/video", consumes=MediaType.MULTIPART_FORM_DATA_VALUE)
  public ResponseEntity<?> video(@RequestPart("file") MultipartFile file) throws Exception{
    String username=currentUser(); String jobId=UUID.randomUUID().toString(); String key="uploads/"+username+"/"+jobId+"/"+file.getOriginalFilename();
    s3.putObject(key, file.getBytes(), file.getContentType()); String modelJson=model.inferVideo(file.getBytes(), file.getOriginalFilename());
    repo.putJob(JobItem.builder().pk("USER#"+username).sk("JOB#"+jobId).modality("video").s3Key(key).modelResponseJson(modelJson).createdAt(System.currentTimeMillis()).build());
    return ResponseEntity.ok(Map.of("jobId",jobId, "result", new JSONObject(modelJson).toMap()));
  }
}
