
package com.vidhan.emotionapi.model;

import lombok.*;
import software.amazon.awssdk.enhanced.dynamodb.mapper.annotations.*;

@Data @Builder @NoArgsConstructor @AllArgsConstructor
@DynamoDbBean
public class UserItem {
  private String pk; private String sk; private String username; private String email; private String passwordHash;
  @DynamoDbPartitionKey public String getPk(){ return pk; }
  @DynamoDbSortKey public String getSk(){ return sk; }
}
