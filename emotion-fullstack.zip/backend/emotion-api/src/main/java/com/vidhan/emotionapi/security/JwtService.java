
package com.vidhan.emotionapi.security;

import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.SignatureAlgorithm;
import io.jsonwebtoken.security.Keys;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import java.time.*; import java.util.*; import java.util.Date;

@Service
public class JwtService {
  @Value("${app.jwt.secret}") private String secret;
  @Value("${app.jwt.expirationMinutes}") private long expMinutes;

  public String issueToken(String username){
    Instant now = Instant.now();
    return Jwts.builder()
      .setSubject(username)
      .setIssuedAt(Date.from(now))
      .setExpiration(Date.from(now.plus(Duration.ofMinutes(expMinutes))))
      .signWith(Keys.hmacShaKeyFor(secret.getBytes()), SignatureAlgorithm.HS256)
      .compact();
  }
  public String validateAndGetUsername(String token){
    try{
      return Jwts.parserBuilder().setSigningKey(Keys.hmacShaKeyFor(secret.getBytes())).build()
        .parseClaimsJws(token).getBody().getSubject();
    }catch(Exception e){ return null; }
  }
}
