
# Emotion Fullstack (Spring Boot + React)

A simple-but-powerful full stack for **Emotion Detection** using a pluggable **AI Model API**.

- **Backend**: Java **Spring Boot 3** (JWT auth, S3 uploads, DynamoDB logging)
- **Frontend**: **React + Vite + TypeScript + Material UI** (Login, Upload, Results)

## Quick Start

### Backend
```bash
cd backend/emotion-api
# Configure application.yml (bucket, table, modelBaseUrl)
mvn spring-boot:run
```

### Frontend
```bash
cd frontend/emotion-frontend
npm install
npm run dev
# open http://localhost:5173
```

## Where to plug your own Emotion Model API
Change these in **backend** `src/main/resources/application.yml`:
```yaml
app:
  ai:
    modelBaseUrl: "http://127.0.0.1:8000"  # <-- set your model host
    textPath: "/predict/text"
    audioPath: "/predict/audio"
    videoPath: "/predict/video"
```
If your response JSON differs, adapt `ModelClient.java` or normalize in `InferenceController.java`.

## AWS
- **DynamoDB** (table: `emotion_student`, keys: `pk` (HASH), `sk` (RANGE))
- **S3** (bucket for media uploads). Configure IAM or local credentials.

## Pages
1) **Login/Register** → JWT
2) **Upload** (text/audio/video) → calls backend → backend calls model → stores in AWS
3) **Results** → displays model output

MIT Licensed.
