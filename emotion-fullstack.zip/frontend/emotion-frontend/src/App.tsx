
import { useEffect, useState } from 'react'
import { Routes, Route, Navigate } from 'react-router-dom'
import Login from './pages/Login'
import Upload from './pages/Upload'
import Results from './pages/Results'
import { setToken } from './api'

export default function App(){
  const [jwt,setJwt] = useState<string|null>(localStorage.getItem('token'))
  useEffect(()=>setToken(jwt),[jwt])
  return (
    <Routes>
      <Route path='/' element={<Login onAuth={(t)=>{localStorage.setItem('token',t); setJwt(t)}}/>} />
      <Route path='/upload' element={jwt ? <Upload/> : <Navigate to='/' replace/>} />
      <Route path='/results' element={jwt ? <Results/> : <Navigate to='/' replace/>} />
    </Routes>
  )
}
