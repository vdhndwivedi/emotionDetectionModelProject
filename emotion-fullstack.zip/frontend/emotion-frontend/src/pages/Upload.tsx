
import { useState } from 'react'
import { Container, Tabs, Tab, TextField, Button, Typography, Box } from '@mui/material'
import api from '../api'
import { useNavigate } from 'react-router-dom'

export default function Upload(){
  const [tab,setTab]=useState<'text'|'audio'|'video'>('text')
  const [text,setText]=useState('')
  const [file,setFile]=useState<File|null>(null)
  const nav=useNavigate()

  const post = async()=>{
    let res
    if(tab==='text'){
      res = await api.post('/infer/text',{text})
    } else {
      const fd = new FormData(); if(!file) return; fd.append('file', file)
      res = await api.post(`/infer/${tab}`, fd, { headers:{'Content-Type':'multipart/form-data'} })
    }
    sessionStorage.setItem('lastResult', JSON.stringify(res.data.result))
    nav('/results')
  }

  return (
    <Container maxWidth='sm' sx={{mt:4}}>
      <Typography variant='h6' mb={2}>Upload Input</Typography>
      <Tabs value={tab} onChange={(_,v)=>setTab(v)}>
        <Tab label='Text' value='text'/><Tab label='Audio' value='audio'/><Tab label='Video' value='video'/>
      </Tabs>
      {tab==='text' && <Box mt={2}><TextField label='Your Text' fullWidth multiline rows={6} value={text} onChange={e=>setText(e.target.value)} /></Box>}
      {tab!=='text' && <Box mt={2}><input type='file' accept={tab==='audio'?'audio/*':'video/*'} onChange={e=>setFile(e.target.files?.[0]??null)} /></Box>}
      <Box mt={2}><Button variant='contained' onClick={post}>Post</Button></Box>
    </Container>
  )
}
