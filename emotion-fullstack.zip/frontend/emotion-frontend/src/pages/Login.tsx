
import { useState } from 'react'
import { Container, TextField, Button, Tabs, Tab, Typography, Box } from '@mui/material'
import api from '../api'
import { useNavigate } from 'react-router-dom'

export default function Login({onAuth}:{onAuth:(t:string)=>void}){
  const [mode,setMode]=useState<'login'|'register'>('login')
  const [username,setUsername]=useState('')
  const [email,setEmail]=useState('')
  const [password,setPassword]=useState('')
  const nav=useNavigate()

  const submit = async()=>{
    if(mode==='register') await api.post('/auth/register',{username,email,password})
    const {data}=await api.post('/auth/login',{username,password})
    onAuth(data.token); nav('/upload')
  }

  return (
    <Container maxWidth='xs' sx={{mt:8}}>
      <Typography variant='h5' mb={2}>Emotion App</Typography>
      <Tabs value={mode} onChange={(_,v)=>setMode(v)}>
        <Tab label='Login' value='login'/>
        <Tab label='Register' value='register'/>
      </Tabs>
      <Box mt={2} display='flex' flexDirection='column' gap={2}>
        <TextField label='Username' value={username} onChange={e=>setUsername(e.target.value)}/>
        {mode==='register' && <TextField label='Email' value={email} onChange={e=>setEmail(e.target.value)}/>}        
        <TextField label='Password' type='password' value={password} onChange={e=>setPassword(e.target.value)}/>
        <Button variant='contained' onClick={submit}>{mode==='register'?'Register & Login':'Login'}</Button>
      </Box>
    </Container>
  )
}
