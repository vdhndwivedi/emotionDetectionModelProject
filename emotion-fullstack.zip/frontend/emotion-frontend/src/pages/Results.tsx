
import { useMemo } from 'react'
import { Container, Typography, List, ListItem, ListItemText, Box, Paper } from '@mui/material'

export default function Results(){
  const data = useMemo(()=>{ const raw=sessionStorage.getItem('lastResult'); return raw?JSON.parse(raw):null },[])
  if(!data) return <Container sx={{mt:4}}><Typography>No result found.</Typography></Container>
  const list = Array.isArray(data) ? data : (data.labels && data.probs ? data.labels.map((l:string,i:number)=>({label:l,score:data.probs[i]})) : [])
  return (
    <Container maxWidth='sm' sx={{mt:4}}>
      <Typography variant='h6' gutterBottom>Emotional Analysis</Typography>
      <Paper variant='outlined'><List>
        {list.map((x:any,i:number)=> <ListItem key={i} divider><ListItemText primary={`${x.label}`} secondary={`score: ${Number(x.score).toFixed(3)}`}/></ListItem>)}
      </List></Paper>
      {data.top_label && <Box mt={2}><Typography><b>Top:</b> {data.top_label} ({(data.top_score*100).toFixed(1)}%)</Typography></Box>}
    </Container>
  )
}
